#---------------------------------------------------------------------------

from GameOfLife import *
from GameParameters import *

thisGen = []
nextGen = []

initGrid(ROWS, COLS,  thisGen)

nextGen = copy.deepcopy(thisGen)

printGen(ROWS, COLS, thisGen, 0)

for gens in range(1, GENERATIONS+1):
    processNextGen(ROWS, COLS, thisGen, nextGen)
    input("Press ENTER to see next generation")
    printGen(ROWS, COLS, nextGen, gens)
    thisGen = copy.deepcopy(nextGen)
input("Finished. Press ENTER to quit.")
