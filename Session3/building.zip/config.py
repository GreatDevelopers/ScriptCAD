stories=2                       #Number of stories

dep_of_foun=6.0                 #Depth of Foundation

plinth_lev=4.0                  #Plinth level of building

clear_height=[10,9]             #Clear Height of each story

dep_slab=0.7                    #Depth of Slab

rep_span_len="2@8+9+1@10+2@12"  #Representation of span length

rep_span_wid="2@7+6+1@5"        #Representation of span width

col_type=1                      #Column type 0 for cylindrical and 1 for rectangular

len_col=1  						#Length of Column (for column type 1)

wid_col=1  						#Width of Column (for column type 1)

radius_col=.5                   #Radius of column (for column type 0)

dep_beam=2                      #Depth of Beam

wid_beam=1                      #Width of Beam

